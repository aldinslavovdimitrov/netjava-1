excercise 5 is quite simple, but demonstrate that thread priority doesn't
affect the thread's execution too much, since the cpu decides which threads
are ready to execute. 

Just as explained in the exercise, you have 2 classes with main(): TestThread 
and TestThread2. TestThread shows how threads without a priority execute and
TestThread2 shows how they execute with priorities.

Solved:100%