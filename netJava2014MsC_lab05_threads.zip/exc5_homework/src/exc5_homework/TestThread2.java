/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc5_homework;

/**
 *
 * @author Merx3
 */
public class TestThread2 {
    public static void main(String[] args) {
        // TODO code application logic here
        
        IntThread thread1 = new IntThread(1);        
        IntThread thread2 = new IntThread(2);
        IntThread thread3 = new IntThread(3);
       
        thread1.setPriority(Thread.MIN_PRIORITY);
        thread2.setPriority(Thread.MIN_PRIORITY + 1);
        thread3.setPriority(Thread.MIN_PRIORITY + 2); 

        thread1.start();
        thread2.start();
        thread3.start();
    }
}
