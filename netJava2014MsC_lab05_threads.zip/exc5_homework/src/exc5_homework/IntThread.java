/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc5_homework;

/**
 *
 * @author Merx3
 */
public class IntThread extends Thread  {
    private int num;
    
    public IntThread(int n){
        this.num = n;
    }
    
    public void run(){
        for(int i=0; i<15; i++){
            System.out.println(this.num);
        }
    }
}
