/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc9_homework;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Merx3
 */
class UDPClient {

    public static void main(String args[]) {
        try {
            int port = 9254;
            DatagramSocket clientSocket = new DatagramSocket();
            clientSocket.setSoTimeout(10000);
            InetAddress ip = InetAddress.getByName("127.0.0.1");
            byte[] sendData = new byte[1024];
            String sendMsg = "iPING!";
            sendData = sendMsg.getBytes();
            int tries = 0;
            while(tries < 4){ 
                try {
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ip, port);
                    clientSocket.send(sendPacket);
                    System.out.println("packet send.");
                    
                    DatagramPacket response = new DatagramPacket(new byte[1024], 1024);
                    clientSocket.receive(response);
                    String responseSentence = new String(response.getData());                    
                    System.out.println("On client from server:" + responseSentence);
                }
                catch (SocketTimeoutException e) {
                    System.out.println("Timeout reached!!! " + e);
                }
                tries++;
            }
            clientSocket.close();
        } 
        catch (SocketException ex) {
            System.out.println(ex.getMessage());
        }
        catch (UnknownHostException ex) {
            System.out.println(ex.getMessage());
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
