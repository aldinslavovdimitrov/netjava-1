/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc9_homework;

import java.io.*;
import java.net.*;

/**
 *
 * @author Merx3
 */
public class UDPServer extends Thread {

    public static void main(String args[]) {
        UDPServer server = new UDPServer();
        server.start();
    }

    public void run() {
        try {
            int version = 1;
            int port = 9254;
            DatagramSocket serverSocket = new DatagramSocket(port);
            System.out.println("Waiting for ping packets.");
            if (version == 1) {
                int response_count = 3;
                while (response_count > 0) {
                    sendResponceOnRecieve(serverSocket);
                    response_count--;
                }
            } else {
                while (true) {
                    sendResponceOnRecieve(serverSocket);
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void sendResponceOnRecieve(DatagramSocket serverSocket) throws IOException {
        byte[] sendData = new byte[1024];
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        serverSocket.receive(receivePacket);
        String received = new String(receivePacket.getData());
        System.out.println("packet received.");
        if (received.contains("PING")) {
            String response = "iPONG!";
            InetAddress IPAddress = receivePacket.getAddress();
            int port = receivePacket.getPort();
            sendData = response.getBytes();
            DatagramPacket sendPacket
                    = new DatagramPacket(sendData, sendData.length, IPAddress, port);
            serverSocket.send(sendPacket);
        }
    }
}
