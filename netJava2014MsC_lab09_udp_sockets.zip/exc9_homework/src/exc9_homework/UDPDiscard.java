/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc9_homework;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 *
 * @author Merx3
 */
public class UDPDiscard extends Thread {

    public static void main(String args[]) {
        UDPDiscard server = new UDPDiscard();
        server.start();
    }

    public void run() {
        try {
            int version = 1;
            int port = 9254;
            DatagramSocket serverSocket = new DatagramSocket(port);
            System.out.println("Disgarding ping packets.");            
            while (true) {
                sendResponceOnRecieve(serverSocket);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void sendResponceOnRecieve(DatagramSocket serverSocket) throws IOException {
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        serverSocket.receive(receivePacket);
        String received = new String(receivePacket.getData());
        System.out.println("packet received. disgarded");        
    }
}

