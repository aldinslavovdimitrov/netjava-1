excercise 9 requires the UDPServer/UDPDisgard to be ran first. After that run UDPClient, on which
you can change the ping version(a variable in the class)

Note: Firewall and other security settings may stop the packets

Task 1, 2 and 3: Solved 100%