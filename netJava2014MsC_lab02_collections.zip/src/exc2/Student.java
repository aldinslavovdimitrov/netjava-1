package exc2;        
        
public class Student implements Comparable{
    private String _name;
    public long _fnum;
    public float _avgGrade;
    
    public String getName(){
        return _name;
    }
    
    public Student setName(String name){
        this._name = name;
        return this;
    }
    
    public long getFacNumber(){
        return _fnum;
    }
    
    public Student setFacNumber(long facNum){
        this._fnum = facNum;
        return this;
    }
    
    public float getAverageGrade(){
        return _avgGrade;
    }
    
    public Student setAverageGrade(float avgGrade){
        this._avgGrade = avgGrade;
        return this;
    }
    
    public Student(){
        setName("Anonymous");
        setAverageGrade(0.0f);
        setFacNumber(0);
    }
    
    @Override
    public int compareTo(Object o) {
        Student compareToStudent = (Student)o;
        float avg_compare = compareToStudent.getAverageGrade() - this._avgGrade;
        if(avg_compare > 0){
            return 1;
        }
        else if(avg_compare < 0){
            return -1;
        }
        else{
            return this._name.compareTo(compareToStudent.getName());
        }
    }

    @Override
    public String toString() {
        return "Name: " + this.getName() + 
               " Fac num: " + this.getFacNumber() + 
               " Average grade: " + this.getAverageGrade() +
               System.getProperty("line.separator");
    }
}
