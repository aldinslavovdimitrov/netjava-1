package exc2;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author grade
 */
public class FunctionClass {
    
    public static void main(String[] args){
        List<Student> students = new ArrayList<Student>();
        students.add(new Student().
                setName("Marian Marinov").
                setFacNumber(24700).
                setAverageGrade(3.00f)
        );
        students.add(new Student().
                setName("Ivan Ivanov").
                setFacNumber(24701).
                setAverageGrade(5.00f)
        );
        students.add(new Student().
                setName("Petar Stoqnov").
                setFacNumber(24702).
                setAverageGrade(4.52f)
        );
        students.add(new Student().
                setName("Milen Stoqnov").
                setFacNumber(24703).
                setAverageGrade(4.00f)
        );        
        students.add(new Student().
                setName("Krasen Stanchev").
                setFacNumber(24704).
                setAverageGrade(2.00f)
        );     
        students.add(new Student().
                setName("Naiden Naidenov").
                setFacNumber(24705).
                setAverageGrade(2.00f)
        );     
        students.add(new Student().
                setName("Kaloqn Stoimenov").
                setFacNumber(24706).
                setAverageGrade(2.00f)
        );
        students.add(new Student().
                setName("Kiril Biznesmencheto").
                setFacNumber(24707).
                setAverageGrade(2.00f)
        );
             
        Collections.sort(students);
        for (Student student : students) {
            System.out.println(student);            
        }
    }
}
