FunctionClass and Student are described in the exercise.
The function class has the main class

Solved:100%