exercise 8 demonstrate how multithreading affects client server communication

To run the example, create a (preferrably large) file in C:/temp called "test.txt". 
This is the file that the server will give to the client. Next, run the 
ultithreadedRemoteFileServer.java file and after that FileClient.java. 

The console will just show the successful transfer. As we can see, the transfers are 
per socket, so this examples shows that even though the transfer happens in a 
separate thread, the port is being blocked and unusable, so this way of multithreading
is practically useless.

Solved:100%