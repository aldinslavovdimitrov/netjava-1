/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc8_homework;

/**
 *
 * @author Merx3
 */

import java.io.*;
import java.net.*;
public class FileClient {

    protected BufferedReader socketReader;
    protected PrintWriter socketWriter;
    protected String hostIp;
    protected int port;

    public FileClient(String aHostIp, int p) {
        hostIp = aHostIp;
        port = p;
    }

    public String getFile(String fileNameToGet) {
        StringBuffer fileLines = new StringBuffer();
        try {
            socketWriter.println(fileNameToGet);
            socketWriter.flush();
            String line = null;
            while ((line = socketReader.readLine()) != null) {
                fileLines.append(line + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + fileNameToGet);
        }
        return fileLines.toString();
    }

    public static void main(String[] args) {    
        FileClient remoteFileClient = new FileClient("127.0.0.1", 3000);
        for (int i = 0; i < 10; i++) {
            remoteFileClient.setUpConnection();
            String fileContents = remoteFileClient.getFile("C:\\temp\\test.txt");
            if(!fileContents.isEmpty()){
                System.out.println("read file content from server.");                
            }
        }
        remoteFileClient.tearDownConnection();
    }

    public void setUpConnection() {
        try {
            Socket client = new Socket(hostIp, port);
            socketReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            socketWriter = new PrintWriter(client.getOutputStream());
        } catch (UnknownHostException e) {
            System.out.println("Error setting up socket connection: unknown host at " + hostIp + ":" + port);
        } catch (IOException e) {
            System.out.println("Error setting up socket connection: " + e);
        }
    }

    public void tearDownConnection() {
        try {
            socketWriter.close();
            socketReader.close();
        } catch (IOException e) {
            System.out.println("Error tearing down socket connection: " + e);
        }
    }
}
