/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc8_homework;

/**
 *
 * @author Merx3
 */
import java.io.*;
import java.net.*;
public class ConnectionHandler implements Runnable{
    Socket socketToHandle;
    
    public ConnectionHandler(Socket aSocketToHandle) {
        socketToHandle = aSocketToHandle;
    }
    
    public void run() {
        try{
            System.out.println("connection opened.");
            PrintWriter streamWriter = new PrintWriter(socketToHandle.getOutputStream());
            BufferedReader streamReader =
                new BufferedReader(new InputStreamReader(socketToHandle.getInputStream()));
            String fileToRead = streamReader.readLine();
            BufferedReader fileReader = new BufferedReader(new FileReader(fileToRead));
            String line = null;
            while ((line = fileReader.readLine()) != null)
                streamWriter.println(line);
            fileReader.close();
            streamWriter.close();
            streamReader.close();
            System.out.println("connection closed.");
        } catch (Exception e) {
            System.out.println("Error handling a client: " + e);
        }
    }
}
