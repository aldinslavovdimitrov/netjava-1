/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc8_homework;

/**
 *
 * @author Merx3
 */
import java.io.*;
import java.net.*;

public class MultithreadedRemoteFileServer {

    protected int port;

    public MultithreadedRemoteFileServer(int p) {
        port = p;
    }

    public void acceptConnections() {
        try {
            ServerSocket server = new ServerSocket(port, 2);
            Socket incomingConnection = null;
            System.out.println("Waiting for connections.");
            while (true) {
                incomingConnection = server.accept();
                handleConnection(incomingConnection);
            }
        } catch (BindException e) {
            System.out.println("Unable to bind to port " + port);
        } catch (IOException e) {
            System.out.println("Unable to instantiate a ServerSocket on port: " + port);
        }
    }

    public void handleConnection(Socket connectionToHandle) {
        new Thread(new ConnectionHandler(connectionToHandle)).start();
    }

    public static void main(String[] args) {
        MultithreadedRemoteFileServer server = new MultithreadedRemoteFileServer(3000);
        server.acceptConnections();
    }
}
