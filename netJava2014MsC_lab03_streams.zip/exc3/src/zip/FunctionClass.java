/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package zip;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;
import java.util.zip.*;
import javax.imageio.IIOException;

/**
 *
 * @author grade
 */
public class FunctionClass {
    public static void unrar(String zipFileName){
        try{
            ZipFile zipFile = new ZipFile(zipFileName);

            Enumeration<? extends ZipEntry> zipEntries = zipFile.entries();
            
            Map<String, String> files = new HashMap<String, String>();
            while(zipEntries.hasMoreElements()){
                ZipEntry entry = zipEntries.nextElement();
                InputStream stream = zipFile.getInputStream(entry);
                
                StringBuilder fileData = new StringBuilder();
                InputStreamReader reader = new InputStreamReader(stream);
                int bufSize = 1024;
                char[] buf = new char[bufSize];
                int numRead=0;
                while((numRead=reader.read(buf, 0, bufSize)) != -1){
                    String readData = String.valueOf(buf, 0, numRead);
                    fileData.append(readData);
                }
                reader.close();
                stream.close();
                files.put(entry.getName(), fileData.toString());
                fileData.delete(0, fileData.length());
            }
            
            createFiles(files, zipFileName);
            zipFile.close();
        }
        catch(IOException e){
            System.out.println("Unraring failed");
        }        
    }
    
    public static void createFiles(Map<String, String> files, String zipLocation){
        File zipFile = new File(zipLocation);
        if(zipFile.isDirectory()){
            throw new IllegalArgumentException("The path to the zip file is a directory.");
        }
        File zipDir = zipFile.getParentFile();
        for (Entry<String, String> file : files.entrySet()) {
            try{
                File f = new File(zipDir, file.getKey());
                //TODO overwrite files if exist      
                byte[] content = file.getValue().getBytes();
                FileOutputStream output = new FileOutputStream(f, false);
                output.write(content);
                output.flush();
                output.close();
            }
            catch(IOException e){
                System.out.println("Rewriting failed");
            }
        }                    
    }
    
    public static void mergeFiles(ArrayList<String> files, String mergedFileName){
        int bufferSize = 1024;
        byte[] buffer;
        StringBuilder mergedContent = new StringBuilder();
        try{
            for (String filePath : files) {
                buffer = new byte[bufferSize];
                File f = new File(filePath);
                FileInputStream fis = new FileInputStream(f);
                int nRead = 0;
                while((nRead = fis.read(buffer)) != -1)
                {
                    String fContent = new String(buffer, 0, nRead);  
                    mergedContent.append(fContent);
                }
                fis.close();
            }
            
            File f = new File(mergedFileName);
            try{
                PrintWriter tmpFile = new PrintWriter(mergedFileName, "UTF-8");
                tmpFile.println(mergedContent.toString());
                tmpFile.close();
            }
            catch(IOException e){
                System.out.println("Couldn't write to merge file.");
            }
        }
        catch(IOException e){
            System.out.println("Error merging files");            
        }
    }
}
