/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package zip;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.zip.*;
import static zip.FunctionClass.*;
/**
 *
 * @author grade
 */
public class ZipFiles {
    public static int sChunk = 8192; 
    
    public static void main(String args[]) throws IOException/*for the empty read()'s*/ {        
        // hardcoded input, can easily be made console or args input
        String zipFileName = "homework3.zip";
        ArrayList<String> files = new ArrayList<String>();
        files.add("homework3_1.txt");
        files.add("homework3_2.txt");
        files.add("homework3_3.txt");
        String mergedFileName = "homework3_merged.txt";
        String mergedZipName = "homework3_all.zip";
        setup(files);
        System.out.print("Setup complete. Press Enter to archive files.");
        System.in.read();        
        archiveFiles(files, zipFileName);
        System.out.print("Archive complete. Press Enter to delete '.txt' files.");
        System.in.read();     
        // unrar-ing isn't usually a silent overwrite,
        //so I do this to prevent any unexpected behaviour
        deleteFiles(files);
        System.out.print("Deletion complete. Press Enter to unrar,merge and archive files.");
        System.in.read();     
        unrar(zipFileName);
        mergeFiles(files, mergedFileName);
        files.add(mergedFileName);
        archiveFiles(files, mergedZipName);
        System.out.println("Done.");
        Scanner readIn = new Scanner(System.in);
        while(true){
            System.out.print("Do you want to delete generated files? (y/n):");
            String c = readIn.next();
            if(c.equalsIgnoreCase("y")){
                files.add(zipFileName);
                files.add(mergedZipName);
                deleteFiles(files);
                break;
            }
            else if(c.equalsIgnoreCase("n")){
                break;
            }
            else{
                System.out.println("Please enter 'y' or 'n'.");
            }
        }        
    }
    
    private static void archiveFiles(ArrayList<String> files, String outZipFile){
        ZipOutputStream zos;
        FileOutputStream fos;
        try{
            fos = new FileOutputStream(outZipFile);
            zos = new ZipOutputStream(fos);
        }
        catch(IOException e){
            System.out.println("Error creating file " + outZipFile + ".");
            return;
        }
        for (Iterator it = files.iterator(); it.hasNext();) {
            String fileName = (String)it.next(); 
            try {
                FileInputStream in = new FileInputStream(fileName);
                ZipEntry zipEntry = new ZipEntry(fileName);
		zos.putNextEntry(zipEntry);

		byte[] bytes = new byte[sChunk];
		int length;
		while ((length = in.read(bytes, 0 , sChunk)) >= 0) {
			zos.write(bytes, 0, length);
		}

		zos.closeEntry();
                in.close();
            } catch (IOException e) {
                System.out.println("Couldn't compress " + fileName + ".");
            }            
        }       
        try { zos.close(  ); fos.close(); }
        catch (IOException e) {}
    }
    
    private static void setup(ArrayList<String> files){
        for (Iterator it = files.iterator(); it.hasNext();) {
            String fileName = (String)it.next();  
            File f = new File(fileName);
            if(!f.exists() || f.isDirectory()){
                try{
                    PrintWriter tmpFile = new PrintWriter(fileName, "UTF-8");
                    tmpFile.println(fileName + ": This file is going to be compressed\n");
                    tmpFile.close();
                }
                catch(IOException e){
                    System.out.println("Couldn't setup files");
                }
            }
        }
    }   

    private static void deleteFiles(ArrayList<String> files) {
        for(String fName: files){
            File tmp = new File(fName);
            boolean deleted = tmp.delete();
            if (!deleted) {
                System.err.println("File was not deleted successfully");
            }
        }
    }
}
