FunctionClass has the unrar, merge and creaete files functionality, 
while the helper class(ZipFiles) is used for archive-ing, setup, teardown and as main()
There are no prerequisites, the program generates its needed files. It is not implemented
flexible.

Solved:100%