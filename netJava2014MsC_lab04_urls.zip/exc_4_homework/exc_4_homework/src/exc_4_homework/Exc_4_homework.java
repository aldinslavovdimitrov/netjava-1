package exc_4_homework;

import java.net.*;
import java.io.*;

public class Exc_4_homework{

    public static void main(String[] args) throws MalformedURLException, IOException{
        String urlString = "http://upbook.le.tsdoit.org/upbook2012_milen.petrov.png";
        
        URL imgUrl = new URL(urlString);
        BufferedInputStream in = new BufferedInputStream(imgUrl.openStream());
        //Image img;
        ByteArrayOutputStream outImg = new ByteArrayOutputStream();
        int bufSize = 2048;
        byte[] buff = new byte[bufSize];
        int readLength;
        while((readLength = in.read(buff,0, bufSize))!= -1){
            outImg.write(buff, 0, readLength);
        }
        outImg.close();
        in.close();
        byte[] imgContent = outImg.toByteArray();
        
        String fileName = imgUrl.getPath();
        fileName = fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length());
        FileOutputStream imgFile = new FileOutputStream(fileName);
        imgFile.write(imgContent);
        imgFile.close();
        System.out.println("Downloaded file from " + urlString + " to " + fileName);
    }
    
}
