There's only one main function, which downloads the png. The url can be changed 
in the main function, in the variable urlString.

Solved:100%