/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exc10_homework;

/**
 *
 * @author Merx3
 */
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class MulticastServer {
    
    final static String INET_ADDR = "224.0.0.3";
    final static int PORT = 8888;

    public static void main(String[] args) throws UnknownHostException, InterruptedException, IOException {
        InetAddress addr = InetAddress.getByName(INET_ADDR);
     
        List<String> fileContent = Files.readAllLines(Paths.get("test.txt"));
        for (String fc:  fileContent) {
            Thread.sleep(2000);            
            try {
                DatagramSocket serverSocket = new DatagramSocket();
                DatagramPacket msgPacket = new DatagramPacket(fc.getBytes(),
                        fc.getBytes().length, addr, PORT);
                serverSocket.send(msgPacket);
                System.out.println("Server sent: " + fc);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }        
    }
}
