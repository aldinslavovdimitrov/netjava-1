excercise 7 uses a Client, which starts a thread with a running instance of the
Server class. just run the Client class and everything should be running. The 
Client's input is delayed by 1 sec, so that the server can be ready. After that,
it's a simple server-client communication, with the detail that if the client 
sends to the server "end.", the server will release resources and the client will
exit and release its resources as well.

Solved:100%