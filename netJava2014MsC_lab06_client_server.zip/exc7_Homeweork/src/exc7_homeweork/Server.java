/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exc7_homeweork;

import java.net.*;
import java.io.*;

/**
 *
 * @author grade
 */
public class Server implements Runnable{
    private static int port;
    public Server(int port) {
        this.port = port;
    }
    
    public static void Start()throws IOException{      
    }

    @Override
    public void run() {
        try{
            ServerSocket server = new ServerSocket(port);
            Socket inConnection; 
            System.out.println("Server waiting for messages...");
            while(true){
                inConnection = server.accept();
                PrintWriter outToSocket = new PrintWriter(inConnection.getOutputStream(), true);
                InputStream inFromSocket = inConnection.getInputStream();
                BufferedReader streamReader = new BufferedReader(new InputStreamReader(inFromSocket));
                String line;
                while((line=streamReader.readLine())!=null){
                    if(line.toLowerCase().equals("end.")){
                        streamReader.close();
                        outToSocket.close();
                        inFromSocket.close();
                        return;
                    }
                    outToSocket.println(line);
                    // System.out.println("Server: " + line);
                }
            }
        }
        catch(IOException e){}
    }
}
