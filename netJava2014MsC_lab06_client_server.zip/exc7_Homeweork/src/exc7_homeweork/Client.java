/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exc7_homeweork;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author grade
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        (new Thread(new Server(2002))).start();
        try{
            Thread.sleep(1000);
        }
        catch(InterruptedException e)
        {}
        Socket socket = new Socket(InetAddress.getByName(null), 2002);
        PrintWriter outToServer = new PrintWriter(socket.getOutputStream());
        BufferedReader inFromServer = new BufferedReader(
            new InputStreamReader(socket.getInputStream()));
         
        Scanner in = new Scanner(System.in);
        String response;
        for(;;){
           System.out.print("Client:");
           String input = in.nextLine();
           outToServer.println(input);
           outToServer.flush();
           if(input.toLowerCase().equals("end.")){
               break;
           }
           else{
               try {
                    response = inFromServer.readLine();
                    if (response == null || response.equals("")) {
                          System.exit(0);
                      }
                } catch (IOException ex) {
                       response = "[Error]: " + ex;
                }
                System.out.println("Server: " + response);
           }
        }
        in.close();
        outToServer.close();
        inFromServer.close();
        socket.close();
    }
    
}
